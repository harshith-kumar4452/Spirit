'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import dynamic from 'next/dynamic';
import { collection, query, orderBy, onSnapshot, where } from 'firebase/firestore';
import { db } from '@/lib/firebase/config';
import { Complaint, ComplaintStatus, Priority } from '@/lib/utils/types';
import { CategoryBadge } from '@/components/complaints/CategoryBadge';
import { StatusBadge } from '@/components/complaints/StatusBadge';
import { LoadingSpinner } from '@/components/ui/LoadingSpinner';
import { Toast, ToastType } from '@/components/ui/Toast';
import { PRIORITY_COLORS, STATUS_LABELS } from '@/lib/utils/constants';
import { timeAgo } from '@/lib/utils/helpers';
import { updateComplaintStatus } from '@/lib/firebase/firestore';
import { useAuth } from '@/lib/hooks/useAuth';
import {
  FileText,
  Clock,
  CheckCircle,
  XCircle,
  AlertCircle,
  LayoutDashboard,
  List,
  ChevronRight,
  MapPin,
  Heart,
  Shield,
  ThumbsUp,
  ThumbsDown,
  Eye,
  X,
} from 'lucide-react';

const ComplaintMap = dynamic(
  () => import('@/components/map/ComplaintMap').then((mod) => mod.ComplaintMap),
  { ssr: false, loading: () => <div className="w-full h-full bg-slate-100 animate-pulse rounded-xl" /> }
);

type AdminView = 'dashboard' | 'complaints';

export default function AdminDashboardPage() {
  const { user, userData } = useAuth();
  const [complaints, setComplaints] = useState<Complaint[]>([]);
  const [filter, setFilter] = useState<'all' | 'pending' | 'resolved'>('all');
  const [loading, setLoading] = useState(true);
  const [activeView, setActiveView] = useState<AdminView>('dashboard');
  const [toast, setToast] = useState<{ type: ToastType; title: string; message?: string } | null>(null);
  const [actionLoading, setActionLoading] = useState<string | null>(null);

  // Selected complaint for quick-view modal
  const [selectedComplaint, setSelectedComplaint] = useState<Complaint | null>(null);

  useEffect(() => {
    let q;

    if (filter === 'pending') {
      q = query(
        collection(db, 'complaints'),
        where('status', 'in', ['submitted', 'under_review', 'in_progress']),
        orderBy('createdAt', 'desc')
      );
    } else if (filter === 'resolved') {
      q = query(
        collection(db, 'complaints'),
        where('status', '==', 'resolved'),
        orderBy('createdAt', 'desc')
      );
    } else {
      q = query(collection(db, 'complaints'), orderBy('createdAt', 'desc'));
    }

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      })) as Complaint[];
      setComplaints(data);
      setLoading(false);
    });

    return () => unsubscribe();
  }, [filter]);

  const stats = {
    total: complaints.length,
    pending: complaints.filter((c) => c.status === 'submitted').length,
    inProgress: complaints.filter((c) => c.status === 'in_progress').length,
    resolved: complaints.filter((c) => c.status === 'resolved').length,
    rejected: complaints.filter((c) => c.status === 'rejected').length,
  };

  const handleQuickAction = async (complaintId: string, status: ComplaintStatus) => {
    if (!user || !userData) return;
    setActionLoading(complaintId);
    try {
      await updateComplaintStatus(
        complaintId,
        status,
        user.uid,
        userData.displayName,
        status === 'rejected' ? 'Rejected by admin' : 'Accepted by admin',
        undefined
      );
      setToast({
        type: 'success',
        title: status === 'rejected' ? 'Complaint Rejected' : 'Complaint Accepted',
        message: `Complaint has been ${status === 'rejected' ? 'rejected' : 'moved to review'}`,
      });
    } catch (error) {
      setToast({ type: 'error', title: 'Action Failed', message: 'Please try again' });
    } finally {
      setActionLoading(null);
    }
  };

  return (
    <main className="h-[calc(100vh-4rem)] bg-[#0B1120] overflow-hidden">
      <div className="flex h-full">
        {/* LEFT: Full-height Map */}
        <div className="flex-1 relative">
          <ComplaintMap className="h-full w-full !rounded-none" />

          {/* Map overlay - title badge */}
          <div className="absolute top-4 left-4 z-[1000]">
            <div className="flex items-center gap-2 px-4 py-2.5 bg-[#0B1120]/80 backdrop-blur-xl rounded-xl border border-white/10 shadow-2xl">
              <Shield className="w-4 h-4 text-brand-400" />
              <span className="text-sm font-semibold text-white">Admin Command Center</span>
            </div>
          </div>

          {/* Map overlay - stats pills */}
          <div className="absolute bottom-4 left-4 right-4 z-[1000]">
            <div className="flex gap-3 flex-wrap">
              <div className="flex items-center gap-2 px-3 py-2 bg-[#0B1120]/80 backdrop-blur-xl rounded-lg border border-white/10">
                <div className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
                <span className="text-xs font-semibold text-amber-400">{stats.pending} Pending</span>
              </div>
              <div className="flex items-center gap-2 px-3 py-2 bg-[#0B1120]/80 backdrop-blur-xl rounded-lg border border-white/10">
                <div className="w-2 h-2 rounded-full bg-blue-400" />
                <span className="text-xs font-semibold text-blue-400">{stats.inProgress} In Progress</span>
              </div>
              <div className="flex items-center gap-2 px-3 py-2 bg-[#0B1120]/80 backdrop-blur-xl rounded-lg border border-white/10">
                <div className="w-2 h-2 rounded-full bg-emerald-400" />
                <span className="text-xs font-semibold text-emerald-400">{stats.resolved} Resolved</span>
              </div>
              <div className="flex items-center gap-2 px-3 py-2 bg-[#0B1120]/80 backdrop-blur-xl rounded-lg border border-white/10">
                <div className="w-2 h-2 rounded-full bg-red-400" />
                <span className="text-xs font-semibold text-red-400">{stats.rejected} Rejected</span>
              </div>
            </div>
          </div>
        </div>

        {/* RIGHT: Sidebar Panel */}
        <div className="w-[480px] flex-shrink-0 bg-[#0F172A] border-l border-white/10 flex flex-col h-full">
          {/* Sidebar Nav Tabs */}
          <div className="flex border-b border-white/10 flex-shrink-0">
            <button
              onClick={() => setActiveView('dashboard')}
              className={`flex-1 flex items-center justify-center gap-2 px-4 py-4 text-sm font-medium transition-all ${activeView === 'dashboard'
                ? 'text-white border-b-2 border-brand-400 bg-white/5'
                : 'text-white/50 hover:text-white/80 hover:bg-white/5'
                }`}
            >
              <LayoutDashboard className="w-4 h-4" />
              Dashboard
            </button>
            <button
              onClick={() => setActiveView('complaints')}
              className={`flex-1 flex items-center justify-center gap-2 px-4 py-4 text-sm font-medium transition-all ${activeView === 'complaints'
                ? 'text-white border-b-2 border-brand-400 bg-white/5'
                : 'text-white/50 hover:text-white/80 hover:bg-white/5'
                }`}
            >
              <List className="w-4 h-4" />
              View Complaints
            </button>
          </div>

          {/* Sidebar Content */}
          <div className="flex-1 overflow-y-auto">
            {activeView === 'dashboard' ? (
              /* ======= DASHBOARD VIEW ======= */
              <div className="p-6 space-y-6">
                {/* Welcome Header */}
                <div>
                  <h2 className="text-xl font-bold text-white mb-1">Dashboard Overview</h2>
                  <p className="text-sm text-white/50">
                    Real-time complaint analytics
                  </p>
                </div>

                {/* Stat Cards */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="bg-white/5 border border-white/10 rounded-2xl p-5 hover:bg-white/10 transition-all duration-300 group">
                    <div className="flex items-center gap-3 mb-3">
                      <div className="p-2 rounded-xl bg-brand-500/20 group-hover:bg-brand-500/30 transition-colors">
                        <FileText className="w-5 h-5 text-brand-400" />
                      </div>
                    </div>
                    <p className="text-3xl font-bold text-white mb-1">{stats.total}</p>
                    <p className="text-xs text-white/40 uppercase tracking-wider font-medium">Total</p>
                  </div>

                  <div className="bg-white/5 border border-white/10 rounded-2xl p-5 hover:bg-white/10 transition-all duration-300 group">
                    <div className="flex items-center gap-3 mb-3">
                      <div className="p-2 rounded-xl bg-amber-500/20 group-hover:bg-amber-500/30 transition-colors">
                        <Clock className="w-5 h-5 text-amber-400" />
                      </div>
                    </div>
                    <p className="text-3xl font-bold text-white mb-1">{stats.pending}</p>
                    <p className="text-xs text-white/40 uppercase tracking-wider font-medium">Pending</p>
                  </div>

                  <div className="bg-white/5 border border-white/10 rounded-2xl p-5 hover:bg-white/10 transition-all duration-300 group">
                    <div className="flex items-center gap-3 mb-3">
                      <div className="p-2 rounded-xl bg-blue-500/20 group-hover:bg-blue-500/30 transition-colors">
                        <AlertCircle className="w-5 h-5 text-blue-400" />
                      </div>
                    </div>
                    <p className="text-3xl font-bold text-white mb-1">{stats.inProgress}</p>
                    <p className="text-xs text-white/40 uppercase tracking-wider font-medium">In Progress</p>
                  </div>

                  <div className="bg-white/5 border border-white/10 rounded-2xl p-5 hover:bg-white/10 transition-all duration-300 group">
                    <div className="flex items-center gap-3 mb-3">
                      <div className="p-2 rounded-xl bg-emerald-500/20 group-hover:bg-emerald-500/30 transition-colors">
                        <CheckCircle className="w-5 h-5 text-emerald-400" />
                      </div>
                    </div>
                    <p className="text-3xl font-bold text-white mb-1">{stats.resolved}</p>
                    <p className="text-xs text-white/40 uppercase tracking-wider font-medium">Resolved</p>
                  </div>
                </div>

                {/* Resolution Rate */}
                <div className="bg-white/5 border border-white/10 rounded-2xl p-5">
                  <div className="flex items-center justify-between mb-4">
                    <p className="text-sm font-semibold text-white">Resolution Rate</p>
                    <span className="text-2xl font-bold text-emerald-400">
                      {stats.total > 0 ? Math.round((stats.resolved / stats.total) * 100) : 0}%
                    </span>
                  </div>
                  <div className="w-full h-3 bg-white/10 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-brand-500 to-emerald-500 rounded-full transition-all duration-1000"
                      style={{ width: `${stats.total > 0 ? (stats.resolved / stats.total) * 100 : 0}%` }}
                    />
                  </div>
                </div>

                {/* Quick Pending List */}
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <p className="text-sm font-semibold text-white">Needs Attention</p>
                    <button
                      onClick={() => { setActiveView('complaints'); setFilter('pending'); }}
                      className="text-xs text-brand-400 hover:text-brand-300 font-medium transition-colors"
                    >
                      View All →
                    </button>
                  </div>
                  <div className="space-y-2">
                    {complaints
                      .filter((c) => c.status === 'submitted')
                      .slice(0, 3)
                      .map((c) => (
                        <div
                          key={c.id}
                          onClick={() => setSelectedComplaint(c)}
                          className="flex items-center gap-3 p-3 bg-white/5 rounded-xl border border-white/10 hover:bg-white/10 cursor-pointer transition-all group"
                        >
                          <img src={c.imageURL} alt="" className="w-10 h-10 rounded-lg object-cover flex-shrink-0" />
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium text-white truncate">{c.title}</p>
                            <p className="text-xs text-white/40">{c.location.area} • {timeAgo(c.createdAt)}</p>
                          </div>
                          <ChevronRight className="w-4 h-4 text-white/30 group-hover:text-white/60 transition-colors" />
                        </div>
                      ))}
                    {complaints.filter((c) => c.status === 'submitted').length === 0 && (
                      <div className="text-center py-8">
                        <CheckCircle className="w-10 h-10 text-emerald-500/30 mx-auto mb-2" />
                        <p className="text-sm text-white/40">All caught up!</p>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ) : (
              /* ======= COMPLAINTS VIEW ======= */
              <div className="p-4">
                {/* Filter Buttons */}
                <div className="flex gap-2 mb-4">
                  {(['all', 'pending', 'resolved'] as const).map((f) => (
                    <button
                      key={f}
                      onClick={() => setFilter(f)}
                      className={`px-4 py-2 text-xs font-semibold rounded-xl transition-all ${filter === f
                        ? 'bg-brand-500 text-white shadow-[0_0_15px_rgba(59,130,246,0.3)]'
                        : 'bg-white/5 text-white/50 hover:bg-white/10 hover:text-white/80 border border-white/10'
                        }`}
                    >
                      {f === 'all' ? 'All' : f === 'pending' ? 'Pending' : 'Resolved'}
                    </button>
                  ))}
                </div>

                {/* Results Count */}
                <p className="text-xs text-white/40 mb-3 px-1">
                  {complaints.length} complaint{complaints.length !== 1 ? 's' : ''} found
                </p>

                {loading ? (
                  <div className="flex justify-center py-12">
                    <LoadingSpinner />
                  </div>
                ) : (
                  <div className="space-y-4">
                    {complaints.map((complaint) => (
                      <div
                        key={complaint.id}
                        className="bg-white/5 rounded-2xl border border-white/10 hover:border-white/20 overflow-hidden transition-all duration-300 group"
                      >
                        {/* Card Hero Image */}
                        <div className="relative h-40 overflow-hidden">
                          <img
                            src={complaint.imageURL}
                            alt={complaint.title}
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                          />
                          <div className="absolute inset-0 bg-gradient-to-t from-[#0F172A] via-transparent to-transparent" />

                          {/* Priority & Upvotes overlay */}
                          <div className="absolute top-3 left-3 flex items-center gap-2">
                            <span className={`text-[10px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-lg backdrop-blur-md border ${complaint.priority === 'critical' ? 'bg-red-500/30 text-red-300 border-red-500/30' :
                                complaint.priority === 'high' ? 'bg-orange-500/30 text-orange-300 border-orange-500/30' :
                                  complaint.priority === 'medium' ? 'bg-amber-500/30 text-amber-300 border-amber-500/30' :
                                    'bg-slate-500/30 text-slate-300 border-slate-500/30'
                              }`}>
                              {complaint.priority}
                            </span>
                          </div>
                          <div className="absolute top-3 right-3 flex items-center gap-1.5 px-2.5 py-1 bg-black/40 backdrop-blur-md rounded-lg">
                            <Heart className="w-3 h-3 text-pink-400" />
                            <span className="text-xs font-semibold text-white">{complaint.upvotes}</span>
                          </div>
                        </div>

                        {/* Card Body */}
                        <div className="p-4">
                          {/* Badges */}
                          <div className="flex items-center gap-2 mb-2.5 flex-wrap">
                            <CategoryBadge category={complaint.category} small />
                            <StatusBadge status={complaint.status} small />
                          </div>

                          {/* Title */}
                          <h3 className="text-base font-bold text-white mb-2 line-clamp-2 leading-snug">
                            {complaint.title}
                          </h3>

                          {/* Location & Time */}
                          <div className="flex items-center gap-4 text-xs text-white/40 mb-4">
                            <div className="flex items-center gap-1.5">
                              <MapPin className="w-3.5 h-3.5" />
                              <span className="truncate max-w-[140px]">{complaint.location.area}</span>
                            </div>
                            <div className="flex items-center gap-1.5">
                              <Clock className="w-3.5 h-3.5" />
                              <span>{timeAgo(complaint.createdAt)}</span>
                            </div>
                          </div>

                          {/* Action Buttons */}
                          <div className="flex items-center gap-2 pt-3 border-t border-white/5">
                            <Link
                              href={`/admin/complaint/${complaint.id}`}
                              className="flex-1 flex items-center justify-center gap-1.5 px-3 py-2.5 text-xs font-semibold text-white/70 hover:text-white bg-white/5 hover:bg-white/10 rounded-xl transition-all border border-white/10"
                            >
                              <Eye className="w-3.5 h-3.5" />
                              View Details
                            </Link>

                            {complaint.status === 'submitted' && (
                              <>
                                <button
                                  onClick={() => handleQuickAction(complaint.id, 'under_review')}
                                  disabled={actionLoading === complaint.id}
                                  className="flex-1 flex items-center justify-center gap-1.5 px-3 py-2.5 text-xs font-bold text-emerald-400 bg-emerald-500/10 hover:bg-emerald-500/20 rounded-xl transition-all border border-emerald-500/20 disabled:opacity-50"
                                >
                                  <ThumbsUp className="w-3.5 h-3.5" />
                                  Accept
                                </button>
                                <button
                                  onClick={() => handleQuickAction(complaint.id, 'rejected')}
                                  disabled={actionLoading === complaint.id}
                                  className="flex-1 flex items-center justify-center gap-1.5 px-3 py-2.5 text-xs font-bold text-red-400 bg-red-500/10 hover:bg-red-500/20 rounded-xl transition-all border border-red-500/20 disabled:opacity-50"
                                >
                                  <ThumbsDown className="w-3.5 h-3.5" />
                                  Reject
                                </button>
                              </>
                            )}

                            {actionLoading === complaint.id && (
                              <LoadingSpinner />
                            )}
                          </div>
                        </div>
                      </div>
                    ))}

                    {complaints.length === 0 && (
                      <div className="text-center py-16">
                        <FileText className="w-12 h-12 text-white/10 mx-auto mb-3" />
                        <p className="text-white/40 text-sm">No complaints found</p>
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Quick View Modal */}
      {selectedComplaint && (
        <div className="fixed inset-0 z-[9999] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setSelectedComplaint(null)} />
          <div className="relative bg-[#0F172A] border border-white/10 rounded-3xl shadow-2xl max-w-lg w-full mx-4 overflow-hidden">
            {/* Modal Image */}
            <div className="relative h-56">
              <img src={selectedComplaint.imageURL} alt="" className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0F172A] to-transparent" />
              <button
                onClick={() => setSelectedComplaint(null)}
                className="absolute top-3 right-3 p-2 bg-black/50 backdrop-blur-md rounded-full text-white/70 hover:text-white transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Content */}
            <div className="p-6 -mt-8 relative z-10">
              <div className="flex items-center gap-2 mb-3">
                <CategoryBadge category={selectedComplaint.category} />
                <StatusBadge status={selectedComplaint.status} />
              </div>
              <h2 className="text-xl font-bold text-white mb-2">{selectedComplaint.title}</h2>
              {selectedComplaint.description && (
                <p className="text-sm text-white/60 mb-4 leading-relaxed">{selectedComplaint.description}</p>
              )}

              <div className="flex items-center gap-2 text-sm text-white/40 mb-2">
                <MapPin className="w-4 h-4" />
                <span>{selectedComplaint.location.address}</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-white/40 mb-6">
                <Clock className="w-4 h-4" />
                <span>Submitted {timeAgo(selectedComplaint.createdAt)}</span>
              </div>

              {/* Action Buttons */}
              <div className="flex gap-3">
                <Link
                  href={`/admin/complaint/${selectedComplaint.id}`}
                  className="flex-1 flex items-center justify-center gap-2 py-3 bg-brand-500 hover:bg-brand-400 text-white font-semibold rounded-xl transition-all"
                >
                  <Eye className="w-4 h-4" />
                  Full Details
                </Link>
                {selectedComplaint.status === 'submitted' && (
                  <>
                    <button
                      onClick={() => { handleQuickAction(selectedComplaint.id, 'under_review'); setSelectedComplaint(null); }}
                      className="py-3 px-5 bg-emerald-500/20 text-emerald-400 font-semibold rounded-xl hover:bg-emerald-500/30 transition-all border border-emerald-500/20"
                    >
                      <ThumbsUp className="w-5 h-5" />
                    </button>
                    <button
                      onClick={() => { handleQuickAction(selectedComplaint.id, 'rejected'); setSelectedComplaint(null); }}
                      className="py-3 px-5 bg-red-500/20 text-red-400 font-semibold rounded-xl hover:bg-red-500/30 transition-all border border-red-500/20"
                    >
                      <ThumbsDown className="w-5 h-5" />
                    </button>
                  </>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {toast && (
        <Toast type={toast.type} title={toast.title} message={toast.message} onClose={() => setToast(null)} />
      )}
    </main>
  );
}

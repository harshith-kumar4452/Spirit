'use client';

import { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import dynamic from 'next/dynamic';
import { doc, onSnapshot, collection, query, orderBy } from 'firebase/firestore';
import { db } from '@/lib/firebase/config';
import { Complaint, ActivityLog, ComplaintStatus, Priority } from '@/lib/utils/types';
import { useAuth } from '@/lib/hooks/useAuth';
import { CategoryBadge } from '@/components/complaints/CategoryBadge';
import { StatusBadge } from '@/components/complaints/StatusBadge';
import { LoadingSpinner } from '@/components/ui/LoadingSpinner';
import { Toast, ToastType } from '@/components/ui/Toast';
import { updateComplaintStatus } from '@/lib/firebase/firestore';
import { timeAgo } from '@/lib/utils/helpers';
import { ArrowLeft, Heart, MapPin, Clock } from 'lucide-react';
import { STATUS_LABELS } from '@/lib/utils/constants';

const MapContainer = dynamic(() => import('react-leaflet').then((mod) => mod.MapContainer), { ssr: false });
const TileLayer = dynamic(() => import('react-leaflet').then((mod) => mod.TileLayer), { ssr: false });
const Marker = dynamic(() => import('react-leaflet').then((mod) => mod.Marker), { ssr: false });

export default function AdminComplaintDetailPage() {
  const params = useParams();
  const router = useRouter();
  const { user, userData } = useAuth();
  const complaintId = params.id as string;

  const [complaint, setComplaint] = useState<Complaint | null>(null);
  const [activity, setActivity] = useState<ActivityLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [updating, setUpdating] = useState(false);

  const [selectedStatus, setSelectedStatus] = useState<ComplaintStatus>('submitted');
  const [selectedPriority, setSelectedPriority] = useState<Priority>('medium');
  const [notes, setNotes] = useState('');
  const [toast, setToast] = useState<{ type: ToastType; title: string; message?: string } | null>(null);

  useEffect(() => {
    if (!complaintId) return;

    const unsubscribe = onSnapshot(doc(db, 'complaints', complaintId), (snapshot) => {
      if (snapshot.exists()) {
        const data = { id: snapshot.id, ...snapshot.data() } as Complaint;
        setComplaint(data);
        setSelectedStatus(data.status);
        setSelectedPriority(data.priority);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, [complaintId]);

  useEffect(() => {
    if (!complaintId) return;

    const q = query(collection(db, 'complaints', complaintId, 'activity'), orderBy('timestamp', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      })) as ActivityLog[];
      setActivity(data);
    });

    return () => unsubscribe();
  }, [complaintId]);

  const handleUpdate = async () => {
    if (!user || !userData || !complaint || updating) return;

    setUpdating(true);
    try {
      await updateComplaintStatus(
        complaint.id,
        selectedStatus,
        user.uid,
        userData.displayName,
        notes || undefined,
        selectedPriority
      );

      setToast({
        type: 'success',
        title: 'Complaint Updated',
        message: 'Status and priority have been updated',
      });

      setNotes('');
    } catch (error) {
      console.error('Update error:', error);
      setToast({
        type: 'error',
        title: 'Update Failed',
        message: 'Please try again',
      });
    } finally {
      setUpdating(false);
    }
  };

  if (loading || !complaint) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  return (
    <main className="min-h-screen bg-slate-50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <button
            onClick={() => router.back()}
            className="inline-flex items-center gap-2 text-sm text-slate-600 hover:text-slate-900"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Dashboard
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Content - 2/3 */}
          <div className="lg:col-span-2 space-y-6">
            {/* Hero Image */}
            <div className="rounded-xl overflow-hidden border border-slate-200 shadow-sm">
              <img src={complaint.imageURL} alt={complaint.title} className="w-full h-80 object-cover" />
            </div>

            {/* Complaint Details */}
            <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6">
              <div className="flex items-center gap-2 mb-4">
                <CategoryBadge category={complaint.category} />
                <StatusBadge status={complaint.status} />
              </div>

              <h1 className="text-2xl font-bold text-slate-900 mb-4">{complaint.title}</h1>

              {complaint.description && (
                <p className="text-slate-700 mb-4 leading-relaxed">{complaint.description}</p>
              )}

              <div className="flex items-start gap-2 text-sm text-slate-600 mb-2">
                <MapPin className="w-4 h-4 flex-shrink-0 mt-0.5" />
                <span>{complaint.location.address}</span>
              </div>

              <div className="flex items-center gap-2 text-sm text-slate-600 mb-6">
                <Clock className="w-4 h-4 flex-shrink-0" />
                <span>Submitted {timeAgo(complaint.createdAt)}</span>
              </div>

              <div className="h-48 rounded-xl overflow-hidden border border-slate-200">
                <MapContainer
                  center={[complaint.location.lat, complaint.location.lng]}
                  zoom={15}
                  className="w-full h-full"
                  zoomControl={false}
                >
                  <TileLayer
                    attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                    url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                  />
                  <Marker position={[complaint.location.lat, complaint.location.lng]} />
                </MapContainer>
              </div>

              <div className="flex items-center justify-between pt-6 border-t border-slate-200 mt-6">
                <div className="flex items-center gap-2 text-sm text-slate-600">
                  <Heart className="w-5 h-5" />
                  <span>{complaint.upvotes} Upvotes</span>
                </div>

                <div className="flex items-center gap-3">
                  <img
                    src={complaint.userPhotoURL}
                    alt={complaint.userName}
                    className="w-10 h-10 rounded-full border-2 border-slate-200"
                  />
                  <div className="text-right">
                    <p className="text-sm font-semibold text-slate-900">{complaint.userName}</p>
                    <p className="text-xs text-slate-500">Reporter</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Activity Timeline */}
            {activity.length > 0 && (
              <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6">
                <h2 className="text-lg font-semibold text-slate-900 mb-4">Activity</h2>
                <div className="space-y-3">
                  {activity.map((log) => (
                    <div key={log.id} className="flex gap-3">
                      <div className="w-2 h-2 rounded-full bg-brand-500 mt-1.5 flex-shrink-0" />
                      <div className="flex-1">
                        <p className="text-sm text-slate-900">
                          {log.action === 'status_change' && (
                            <>
                              Status changed to <strong>{log.toValue}</strong>
                            </>
                          )}
                          {log.action === 'priority_change' && (
                            <>
                              Priority changed to <strong>{log.toValue}</strong>
                            </>
                          )}
                        </p>
                        <p className="text-xs text-slate-500 mt-0.5">
                          by {log.performedByName} • {timeAgo(log.timestamp)}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Admin Actions Panel - 1/3 */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 sticky top-20">
              <h2 className="text-lg font-semibold text-slate-900 mb-4">Admin Actions</h2>

              {/* Status Dropdown */}
              <div className="mb-4">
                <label className="block text-sm font-medium text-slate-700 mb-1.5">Status</label>
                <select
                  value={selectedStatus}
                  onChange={(e) => setSelectedStatus(e.target.value as ComplaintStatus)}
                  className="w-full px-4 py-3 rounded-xl border border-slate-300 bg-white text-slate-900 focus:outline-none focus:ring-2 focus:ring-brand-500 focus:border-transparent"
                >
                  <option value="submitted">{STATUS_LABELS.submitted}</option>
                  <option value="under_review">{STATUS_LABELS.under_review}</option>
                  <option value="in_progress">{STATUS_LABELS.in_progress}</option>
                  <option value="resolved">{STATUS_LABELS.resolved}</option>
                  <option value="rejected">{STATUS_LABELS.rejected}</option>
                </select>
              </div>

              {/* Priority Radio Group */}
              <div className="mb-4">
                <label className="block text-sm font-medium text-slate-700 mb-2">Priority</label>
                <div className="space-y-2">
                  {(['low', 'medium', 'high', 'critical'] as Priority[]).map((priority) => (
                    <label key={priority} className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="radio"
                        value={priority}
                        checked={selectedPriority === priority}
                        onChange={(e) => setSelectedPriority(e.target.value as Priority)}
                        className="w-4 h-4 text-brand-500 focus:ring-brand-500"
                      />
                      <span className="text-sm text-slate-700 capitalize">{priority}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Notes Textarea */}
              <div className="mb-4">
                <label className="block text-sm font-medium text-slate-700 mb-1.5">Notes (optional)</label>
                <textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  rows={3}
                  placeholder="Add internal notes..."
                  className="w-full px-4 py-3 rounded-xl border border-slate-300 bg-white text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-brand-500 focus:border-transparent resize-none"
                />
              </div>

              {/* Update Button */}
              <button
                onClick={handleUpdate}
                disabled={updating}
                className="w-full px-6 py-3 bg-brand-500 hover:bg-brand-600 active:bg-brand-700 text-white font-semibold rounded-xl transition-colors shadow-sm disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {updating ? 'Updating...' : 'Update Complaint'}
              </button>
            </div>
          </div>
        </div>
      </div>

      {toast && (
        <Toast type={toast.type} title={toast.title} message={toast.message} onClose={() => setToast(null)} />
      )}
    </main>
  );
}
